// storage/database.js
// قاعدة البيانات المحلية - تخزن كل البيانات المسحوبة

const Database = require('better-sqlite3');
const path = require('path');
const logger = require('../utils/logger');

const DB_PATH = path.join(__dirname, '../data/aseer_platform.db');

let db;

function getDB() {
  if (!db) {
    const fs = require('fs');
    fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
    
    db = new Database(DB_PATH);
    db.pragma('journal_mode = WAL');  // أداء أفضل
    db.pragma('foreign_keys = ON');
    initSchema();
    logger.info('✅ قاعدة البيانات جاهزة: ' + DB_PATH);
  }
  return db;
}

function initSchema() {
  db.exec(`
    -- ===================================================
    -- جدول فرص الامتياز التجاري
    -- ===================================================
    CREATE TABLE IF NOT EXISTS franchises (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      external_id   TEXT UNIQUE,           -- ID من الموقع الأصلي
      name_ar       TEXT NOT NULL,          -- اسم العلامة بالعربي
      name_en       TEXT,                   -- اسم العلامة بالإنجليزي
      description   TEXT,                   -- وصف المشروع
      sector        TEXT,                   -- القطاع (مطاعم، تجزئة...)
      fee           TEXT,                   -- رسوم الامتياز
      capital_min   INTEGER,                -- الحد الأدنى لرأس المال (ريال)
      capital_max   INTEGER,                -- الحد الأعلى لرأس المال
      royalty_pct   REAL,                   -- نسبة الإتاوة %
      roi_pct       REAL,                   -- العائد المتوقع %
      payback_years REAL,                   -- سنوات استرداد رأس المال
      regions       TEXT,                   -- المناطق المتاحة (JSON array)
      support       TEXT,                   -- الدعم المقدم
      requirements  TEXT,                   -- الشروط والمتطلبات
      contact_email TEXT,
      contact_phone TEXT,
      website_url   TEXT,
      logo_url      TEXT,
      source_url    TEXT,                   -- الرابط الأصلي
      is_active     INTEGER DEFAULT 1,
      scraped_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at    DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    -- ===================================================
    -- جدول الدورات التدريبية - دروب
    -- ===================================================
    CREATE TABLE IF NOT EXISTS courses (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      external_id   TEXT UNIQUE,
      title_ar      TEXT NOT NULL,
      title_en      TEXT,
      description   TEXT,
      provider      TEXT,                   -- الجهة المقدِّمة
      category      TEXT,                   -- الفئة (تجارة، تقنية...)
      level         TEXT,                   -- المستوى (مبتدئ، متوسط...)
      duration_hrs  INTEGER,                -- مدة الدورة بالساعات
      is_free       INTEGER DEFAULT 1,      -- مجانية أم مدفوعة
      price         REAL DEFAULT 0,
      is_certified  INTEGER DEFAULT 0,      -- تمنح شهادة؟
      certificate_type TEXT,               -- نوع الشهادة
      is_required_for TEXT,               -- مطلوبة لترخيص ماذا؟ (JSON)
      enrollment_url TEXT,                 -- رابط التسجيل المباشر
      image_url     TEXT,
      rating        REAL,
      students_count INTEGER DEFAULT 0,
      source_url    TEXT,
      is_active     INTEGER DEFAULT 1,
      scraped_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at    DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    -- ===================================================
    -- جدول برامج الدعم - معهد ريادة الأعمال
    -- ===================================================
    CREATE TABLE IF NOT EXISTS support_programs (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      external_id   TEXT UNIQUE,
      name_ar       TEXT NOT NULL,
      name_en       TEXT,
      provider      TEXT,                   -- الجهة (ريادة، جميل، جنى...)
      description   TEXT,
      program_type  TEXT,                   -- نوع (تمويل، تدريب، إرشاد...)
      target_group  TEXT,                   -- الفئة المستهدفة
      benefits      TEXT,                   -- المزايا (JSON)
      requirements  TEXT,                   -- شروط الأهلية
      amount_min    REAL,                   -- الحد الأدنى للتمويل
      amount_max    REAL,                   -- الحد الأعلى للتمويل
      deadline      DATE,                   -- تاريخ انتهاء التقديم
      apply_url     TEXT,
      contact_info  TEXT,
      regions       TEXT,                   -- المناطق (JSON)
      is_active     INTEGER DEFAULT 1,
      scraped_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at    DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    -- ===================================================
    -- جدول سجل عمليات السحب
    -- ===================================================
    CREATE TABLE IF NOT EXISTS scrape_log (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      source      TEXT NOT NULL,            -- اسم المصدر
      status      TEXT NOT NULL,            -- success / failed / partial
      records_new INTEGER DEFAULT 0,        -- سجلات جديدة
      records_upd INTEGER DEFAULT 0,        -- سجلات محدثة
      records_err INTEGER DEFAULT 0,        -- سجلات فاشلة
      duration_ms INTEGER,                  -- مدة التنفيذ
      error_msg   TEXT,                     -- رسالة الخطأ إن وجدت
      started_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
      finished_at DATETIME
    );

    -- ===================================================
    -- Indexes للأداء
    -- ===================================================
    CREATE INDEX IF NOT EXISTS idx_franchises_sector   ON franchises(sector);
    CREATE INDEX IF NOT EXISTS idx_franchises_capital  ON franchises(capital_min);
    CREATE INDEX IF NOT EXISTS idx_franchises_active   ON franchises(is_active);
    CREATE INDEX IF NOT EXISTS idx_courses_category    ON courses(category);
    CREATE INDEX IF NOT EXISTS idx_courses_free        ON courses(is_free);
    CREATE INDEX IF NOT EXISTS idx_programs_provider   ON support_programs(provider);
    CREATE INDEX IF NOT EXISTS idx_programs_type       ON support_programs(program_type);
    CREATE INDEX IF NOT EXISTS idx_log_source          ON scrape_log(source);
    CREATE INDEX IF NOT EXISTS idx_log_status          ON scrape_log(status);
  `);
}

// ===================================================
// دوال مساعدة للتعامل مع البيانات
// ===================================================
function upsertFranchise(data) {
  const db = getDB();
  const stmt = db.prepare(`
    INSERT INTO franchises (
      external_id, name_ar, name_en, description, sector,
      fee, capital_min, capital_max, royalty_pct, roi_pct,
      payback_years, regions, support, requirements,
      contact_email, contact_phone, website_url, logo_url, source_url
    ) VALUES (
      @external_id, @name_ar, @name_en, @description, @sector,
      @fee, @capital_min, @capital_max, @royalty_pct, @roi_pct,
      @payback_years, @regions, @support, @requirements,
      @contact_email, @contact_phone, @website_url, @logo_url, @source_url
    )
    ON CONFLICT(external_id) DO UPDATE SET
      name_ar       = excluded.name_ar,
      description   = excluded.description,
      sector        = excluded.sector,
      fee           = excluded.fee,
      capital_min   = excluded.capital_min,
      capital_max   = excluded.capital_max,
      regions       = excluded.regions,
      support       = excluded.support,
      logo_url      = excluded.logo_url,
      updated_at    = CURRENT_TIMESTAMP
  `);
  
  const existing = db.prepare('SELECT id FROM franchises WHERE external_id = ?').get(data.external_id);
  const result = stmt.run(data);
  return { isNew: !existing, id: existing?.id || result.lastInsertRowid };
}

function upsertCourse(data) {
  const db = getDB();
  const stmt = db.prepare(`
    INSERT INTO courses (
      external_id, title_ar, title_en, description, provider,
      category, level, duration_hrs, is_free, price,
      is_certified, certificate_type, is_required_for,
      enrollment_url, image_url, rating, students_count, source_url
    ) VALUES (
      @external_id, @title_ar, @title_en, @description, @provider,
      @category, @level, @duration_hrs, @is_free, @price,
      @is_certified, @certificate_type, @is_required_for,
      @enrollment_url, @image_url, @rating, @students_count, @source_url
    )
    ON CONFLICT(external_id) DO UPDATE SET
      title_ar     = excluded.title_ar,
      description  = excluded.description,
      category     = excluded.category,
      is_free      = excluded.is_free,
      price        = excluded.price,
      rating       = excluded.rating,
      students_count = excluded.students_count,
      updated_at   = CURRENT_TIMESTAMP
  `);
  
  const existing = db.prepare('SELECT id FROM courses WHERE external_id = ?').get(data.external_id);
  const result = stmt.run(data);
  return { isNew: !existing, id: existing?.id || result.lastInsertRowid };
}

function upsertProgram(data) {
  const db = getDB();
  const stmt = db.prepare(`
    INSERT INTO support_programs (
      external_id, name_ar, name_en, provider, description,
      program_type, target_group, benefits, requirements,
      amount_min, amount_max, deadline, apply_url, contact_info, regions
    ) VALUES (
      @external_id, @name_ar, @name_en, @provider, @description,
      @program_type, @target_group, @benefits, @requirements,
      @amount_min, @amount_max, @deadline, @apply_url, @contact_info, @regions
    )
    ON CONFLICT(external_id) DO UPDATE SET
      name_ar      = excluded.name_ar,
      description  = excluded.description,
      benefits     = excluded.benefits,
      requirements = excluded.requirements,
      amount_min   = excluded.amount_min,
      amount_max   = excluded.amount_max,
      deadline     = excluded.deadline,
      updated_at   = CURRENT_TIMESTAMP
  `);
  
  const existing = db.prepare('SELECT id FROM support_programs WHERE external_id = ?').get(data.external_id);
  const result = stmt.run(data);
  return { isNew: !existing, id: existing?.id || result.lastInsertRowid };
}

function logScrape(source, status, stats = {}) {
  const db = getDB();
  return db.prepare(`
    INSERT INTO scrape_log (source, status, records_new, records_upd, records_err, duration_ms, error_msg, finished_at)
    VALUES (@source, @status, @records_new, @records_upd, @records_err, @duration_ms, @error_msg, CURRENT_TIMESTAMP)
  `).run({
    source,
    status,
    records_new: stats.new || 0,
    records_upd: stats.updated || 0,
    records_err: stats.errors || 0,
    duration_ms: stats.duration || 0,
    error_msg: stats.error || null
  });
}

function getStats() {
  const db = getDB();
  return {
    franchises: db.prepare('SELECT COUNT(*) as count, MAX(scraped_at) as last FROM franchises WHERE is_active=1').get(),
    courses:    db.prepare('SELECT COUNT(*) as count, MAX(scraped_at) as last FROM courses WHERE is_active=1').get(),
    programs:   db.prepare('SELECT COUNT(*) as count, MAX(scraped_at) as last FROM support_programs WHERE is_active=1').get(),
    lastRuns:   db.prepare('SELECT source, status, records_new, records_upd, started_at FROM scrape_log ORDER BY id DESC LIMIT 10').all()
  };
}

module.exports = { getDB, upsertFranchise, upsertCourse, upsertProgram, logScrape, getStats };
