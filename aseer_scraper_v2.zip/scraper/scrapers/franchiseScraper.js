// scrapers/franchiseScraper.js
// ============================================================
// سحب بيانات منصة الامتياز التجاري السعودية
// الموقع: https://franchise.mci.gov.sa
// ============================================================

const cheerio = require('cheerio');
const { createBrowser, createPage, safeGoto, randomDelay } = require('../utils/browser');
const { upsertFranchise, logScrape } = require('../storage/database');
const logger = require('../utils/logger');

const BASE_URL = 'https://franchise.mci.gov.sa';
const FRANCHISE_LIST_URL = `${BASE_URL}/ar/franchise/list`;

// -------------------------------------------------------
// الخطوة 1: جلب قائمة جميع الامتيازات (الصفحات المتعددة)
// -------------------------------------------------------
async function scrapeAllFranchises() {
  const startTime = Date.now();
  const stats = { new: 0, updated: 0, errors: 0 };
  let browser;

  logger.info('🚀 بدء سحب منصة الامتياز التجاري...');

  try {
    browser = await createBrowser();
    const page = await createPage(browser);

    // --- جلب الصفحة الأولى ---
    const ok = await safeGoto(page, FRANCHISE_LIST_URL);
    if (!ok) throw new Error('تعذّر تحميل صفحة القائمة');

    // --- اكتشاف عدد الصفحات ---
    const totalPages = await page.evaluate(() => {
      // نبحث عن pagination أو عدد النتائج
      const lastPageEl = document.querySelector('.pagination li:last-child a, [aria-label="Last"]');
      if (lastPageEl) return parseInt(lastPageEl.textContent.trim()) || 1;
      const countEl = document.querySelector('.results-count, .total-count');
      if (countEl) {
        const num = parseInt(countEl.textContent.replace(/\D/g, ''));
        return Math.ceil(num / 12) || 1;
      }
      return 1;
    });

    logger.info(`📄 إجمالي الصفحات: ${totalPages}`);

    // --- تمرير كل الصفحات ---
    for (let pageNum = 1; pageNum <= Math.min(totalPages, 50); pageNum++) {
      logger.info(`   📋 معالجة صفحة ${pageNum}/${totalPages}`);

      if (pageNum > 1) {
        const pageUrl = `${FRANCHISE_LIST_URL}?page=${pageNum}`;
        await safeGoto(page, pageUrl);
      }

      // --- استخراج روابط تفاصيل كل امتياز ---
      const franchiseLinks = await page.evaluate((base) => {
        const links = [];
        // الروابط الشائعة في مواقع الامتياز الحكومية
        const selectors = [
          '.franchise-card a',
          '.franchise-item a[href*="detail"]',
          '.card-title a',
          'a[href*="/franchise/"]',
          '.listing-item a'
        ];
        for (const sel of selectors) {
          document.querySelectorAll(sel).forEach(el => {
            const href = el.getAttribute('href');
            if (href && !links.includes(href)) {
              links.push(href.startsWith('http') ? href : base + href);
            }
          });
          if (links.length > 0) break;
        }
        return links;
      }, BASE_URL);

      logger.info(`   🔗 وُجد ${franchiseLinks.length} امتياز في هذه الصفحة`);

      // --- جلب تفاصيل كل امتياز ---
      for (const link of franchiseLinks) {
        try {
          const detail = await scrapeFranchiseDetail(page, link);
          if (detail) {
            const result = upsertFranchise(detail);
            if (result.isNew) stats.new++;
            else stats.updated++;
          }
          await randomDelay(1200, 2800);  // احترام السيرفر
        } catch (err) {
          logger.error(`❌ خطأ في جلب: ${link} - ${err.message}`);
          stats.errors++;
        }
      }

      await randomDelay(2000, 4000);  // تأخير بين الصفحات
    }

    const duration = Date.now() - startTime;
    logScrape('franchise_mci', 'success', { ...stats, duration });
    logger.info(`✅ اكتمل سحب الامتياز: جديد=${stats.new}, محدَّث=${stats.updated}, خطأ=${stats.errors} (${duration}ms)`);

  } catch (err) {
    const duration = Date.now() - startTime;
    logScrape('franchise_mci', 'failed', { ...stats, duration, error: err.message });
    logger.error(`💥 فشل سحب الامتياز: ${err.message}`);
  } finally {
    if (browser) await browser.close();
  }

  return stats;
}

// -------------------------------------------------------
// الخطوة 2: استخراج تفاصيل امتياز واحد
// -------------------------------------------------------
async function scrapeFranchiseDetail(page, url) {
  const ok = await safeGoto(page, url);
  if (!ok) return null;

  const data = await page.evaluate(() => {
    // دالة مساعدة لاستخراج نص بأمان
    const getText = (selectors) => {
      for (const sel of selectors) {
        const el = document.querySelector(sel);
        if (el && el.textContent.trim()) return el.textContent.trim();
      }
      return null;
    };

    const getNum = (selectors) => {
      const txt = getText(selectors);
      if (!txt) return null;
      const cleaned = txt.replace(/[^\d.]/g, '');
      return cleaned ? parseFloat(cleaned) : null;
    };

    const getMeta = (label) => {
      // يبحث عن عنصر يحتوي على label ثم يأخذ القيمة المجاورة
      const allLabels = document.querySelectorAll('.label, .field-label, dt, .info-label, th');
      for (const el of allLabels) {
        if (el.textContent.includes(label)) {
          const val = el.nextElementSibling || el.closest('tr')?.querySelector('td:last-child');
          if (val) return val.textContent.trim();
        }
      }
      return null;
    };

    // اسم العلامة
    const name_ar = getText([
      'h1.franchise-name',
      '.brand-name h1',
      '.detail-title h1',
      '.page-title',
      'h1'
    ]);

    // الوصف
    const description = getText([
      '.franchise-description',
      '.about-franchise',
      '.description-text',
      '.detail-description p'
    ]);

    // القطاع
    const sector = getText([
      '.sector-name',
      '.category-badge',
      '[data-field="sector"]',
    ]) || getMeta('القطاع') || getMeta('المجال');

    // استخراج الأرقام المالية
    const feeText = getText(['.franchise-fee', '[data-field="fee"]']) || getMeta('رسوم الامتياز') || getMeta('رسوم الانضمام');
    const capitalText = getText(['.capital-required', '[data-field="capital"]']) || getMeta('رأس المال') || getMeta('الاستثمار');
    const royaltyText = getText(['.royalty-fee', '[data-field="royalty"]']) || getMeta('الإتاوة') || getMeta('نسبة الإتاوة');

    // المناطق المتاحة
    const regions = [];
    document.querySelectorAll('.region-badge, .available-region, [data-field="regions"] span').forEach(el => {
      regions.push(el.textContent.trim());
    });

    // الدعم
    const support = getText(['.support-description', '[data-field="support"]']) || getMeta('الدعم المقدم');

    // معلومات التواصل
    const contact_email = document.querySelector('a[href^="mailto:"]')?.getAttribute('href')?.replace('mailto:', '') || null;
    const contact_phone = getText(['.phone-number', '[data-field="phone"]']) || getMeta('رقم الجوال');
    const website_url = document.querySelector('.official-website a, [data-field="website"] a')?.getAttribute('href') || null;
    const logo_url = document.querySelector('.franchise-logo img, .brand-logo img')?.getAttribute('src') || null;

    // ROI
    const roi_pct = getNum(['.roi-value', '[data-field="roi"]']);

    return {
      name_ar,
      description,
      sector,
      fee: feeText,
      capital_min: null,  // سيُعالَج لاحقاً
      capital_max: null,
      royalty_pct: royaltyText ? parseFloat(royaltyText.replace(/[^\d.]/g, '')) : null,
      roi_pct,
      payback_years: null,
      regions: JSON.stringify(regions),
      support,
      requirements: null,
      contact_email,
      contact_phone,
      website_url,
      logo_url,
      _capitalText: capitalText,
    };
  });

  if (!data || !data.name_ar) return null;

  // معالجة رأس المال (مثال: "50,000 - 100,000 ريال")
  if (data._capitalText) {
    const nums = data._capitalText.replace(/[,،]/g, '').match(/\d+/g);
    if (nums && nums.length >= 2) {
      data.capital_min = parseInt(nums[0]);
      data.capital_max = parseInt(nums[1]);
    } else if (nums && nums.length === 1) {
      data.capital_min = parseInt(nums[0]);
    }
  }
  delete data._capitalText;

  data.external_id = `franchise_${url.split('/').pop() || Math.random().toString(36).substr(2, 9)}`;
  data.source_url = url;

  return data;
}

module.exports = { scrapeAllFranchises };

// تشغيل مباشر إن تم استدعاء الملف مباشرة
if (require.main === module) {
  scrapeAllFranchises().then(() => process.exit(0));
}
