// scrapers/doroobScraper.js
// ============================================================
// سحب الدورات التدريبية من منصة دروب
// الموقع: https://www.doroob.com.sa
// ============================================================

const cheerio = require('cheerio');
const axios = require('axios');
const { createBrowser, createPage, safeGoto, randomDelay } = require('../utils/browser');
const { upsertCourse, logScrape } = require('../storage/database');
const logger = require('../utils/logger');

const BASE_URL = 'https://www.doroob.com.sa';

// الفئات التي تهمنا لمشروعنا (ريادة أعمال + تراخيص)
const TARGET_CATEGORIES = [
  { name: 'ريادة الأعمال', url: '/ar/individuals/courses/?category=entrepreneurship' },
  { name: 'التجارة والأعمال',  url: '/ar/individuals/courses/?category=business' },
  { name: 'التسويق الرقمي',   url: '/ar/individuals/courses/?category=digital-marketing' },
  { name: 'المحاسبة والمالية', url: '/ar/individuals/courses/?category=accounting' },
  { name: 'سلامة الغذاء',     url: '/ar/individuals/courses/?category=food-safety' },
  { name: 'الموارد البشرية',   url: '/ar/individuals/courses/?category=hr' },
];

// -------------------------------------------------------
// الدورات المطلوبة للتراخيص - خريطة ربط تلقائي
// -------------------------------------------------------
const LICENSE_COURSE_MAP = {
  'مطعم': ['سلامة الغذاء', 'التغذية', 'صحة بيئية'],
  'مقهى': ['سلامة الغذاء', 'المشروبات'],
  'صيدلية': ['صحة', 'دواء'],
  'مدرسة': ['تعليم', 'إدارة تعليمية'],
  'نادي رياضي': ['لياقة', 'سلامة'],
  'تجارة إلكترونية': ['تسويق رقمي', 'إدارة أعمال إلكترونية'],
  'عام': ['ريادة الأعمال', 'التجارة والأعمال'],
};

async function scrapeAllCourses() {
  const startTime = Date.now();
  const stats = { new: 0, updated: 0, errors: 0 };
  let browser;

  logger.info('🚀 بدء سحب دورات منصة دروب...');

  try {
    browser = await createBrowser();
    const page = await createPage(browser);

    for (const category of TARGET_CATEGORIES) {
      logger.info(`  📚 سحب فئة: ${category.name}`);
      await scrapeCategory(page, category, stats);
      await randomDelay(3000, 6000);
    }

    const duration = Date.now() - startTime;
    logScrape('doroob', 'success', { ...stats, duration });
    logger.info(`✅ اكتمل سحب دروب: جديد=${stats.new}, محدَّث=${stats.updated}, خطأ=${stats.errors} (${duration}ms)`);

  } catch (err) {
    const duration = Date.now() - startTime;
    logScrape('doroob', 'failed', { ...stats, duration, error: err.message });
    logger.error(`💥 فشل سحب دروب: ${err.message}`);
  } finally {
    if (browser) await browser.close();
  }

  return stats;
}

async function scrapeCategory(page, category, stats) {
  const url = BASE_URL + category.url;
  const ok = await safeGoto(page, url);
  if (!ok) return;

  // تمرير جميع نتائج الصفحة الواحدة (دروب يستخدم Infinite Scroll)
  await autoScroll(page);

  const courses = await page.evaluate((categoryName, BASE) => {
    const items = [];
    
    // محاولة استخراج بطاقات الدورات
    const cards = document.querySelectorAll([
      '.course-card',
      '.training-card',
      '.course-item',
      '[class*="course"]',
      '.card'
    ].join(', '));

    cards.forEach((card, idx) => {
      if (idx > 100) return; // حد أقصى 100 دورة لكل فئة

      const titleEl = card.querySelector('h2, h3, h4, .course-title, .card-title');
      const title_ar = titleEl?.textContent?.trim();
      if (!title_ar || title_ar.length < 5) return;

      const link = card.querySelector('a')?.getAttribute('href');
      const imgEl = card.querySelector('img');
      const ratingEl = card.querySelector('.rating, .stars, [class*="rating"]');
      const studentsEl = card.querySelector('.students-count, [class*="students"], [class*="enrolled"]');
      const durationEl = card.querySelector('.duration, .course-duration, [class*="duration"]');
      const priceEl = card.querySelector('.price, .course-price, [class*="price"]');
      const badgeEl = card.querySelector('.badge, .category-badge, [class*="badge"]');
      const certEl = card.querySelector('.certificate, [class*="certif"]');
      const descEl = card.querySelector('.description, .course-desc, p');

      const priceText = priceEl?.textContent?.trim() || '';
      const is_free = priceText === '' || priceText.includes('مجاني') || priceText === '0';

      const durationText = durationEl?.textContent?.trim() || '';
      const durationMatch = durationText.match(/(\d+)/);
      const duration_hrs = durationMatch ? parseInt(durationMatch[1]) : null;

      const studentsText = studentsEl?.textContent?.trim() || '';
      const studentsMatch = studentsText.replace(/,|،/g, '').match(/(\d+)/);

      items.push({
        external_id: `doroob_${link?.split('/').filter(Boolean).pop() || idx}`,
        title_ar,
        title_en: null,
        description: descEl?.textContent?.trim()?.substring(0, 500) || null,
        provider: 'دروب',
        category: categoryName,
        level: null,
        duration_hrs,
        is_free: is_free ? 1 : 0,
        price: is_free ? 0 : parseFloat(priceText.replace(/[^\d.]/g, '')) || 0,
        is_certified: certEl ? 1 : 0,
        certificate_type: certEl?.textContent?.trim() || null,
        is_required_for: null,  // سيُحدَّد لاحقاً
        enrollment_url: link ? (link.startsWith('http') ? link : BASE + link) : null,
        image_url: imgEl?.getAttribute('src') || imgEl?.getAttribute('data-src') || null,
        rating: ratingEl ? parseFloat(ratingEl.getAttribute('data-rating') || ratingEl.textContent) || null : null,
        students_count: studentsMatch ? parseInt(studentsMatch[1]) : 0,
        source_url: link ? (link.startsWith('http') ? link : BASE + link) : null,
      });
    });

    return items;
  }, category.name, BASE_URL);

  logger.info(`    ✓ ${courses.length} دورة في فئة ${category.name}`);

  for (const course of courses) {
    try {
      // ربط الدورة بالتراخيص المطلوبة
      course.is_required_for = JSON.stringify(getRequiredLicenses(course.title_ar, course.category));
      const result = upsertCourse(course);
      if (result.isNew) stats.new++;
      else stats.updated++;
    } catch (err) {
      logger.error(`❌ خطأ في حفظ الدورة: ${course.title_ar} - ${err.message}`);
      stats.errors++;
    }
  }
}

// تمرير الصفحة تلقائياً لتحميل كل المحتوى (Infinite Scroll)
async function autoScroll(page) {
  await page.evaluate(async () => {
    await new Promise(resolve => {
      let totalHeight = 0;
      const distance = 400;
      const timer = setInterval(() => {
        window.scrollBy(0, distance);
        totalHeight += distance;
        if (totalHeight >= document.body.scrollHeight || totalHeight > 15000) {
          clearInterval(timer);
          resolve();
        }
      }, 200);
    });
  });
  await randomDelay(1000, 2000);
}

// تحديد الدورة هل هي مطلوبة لترخيص معين
function getRequiredLicenses(title, category) {
  const required = [];
  const titleLower = title.toLowerCase();
  
  for (const [licenseType, keywords] of Object.entries(LICENSE_COURSE_MAP)) {
    for (const keyword of keywords) {
      if (title.includes(keyword) || category.includes(keyword)) {
        required.push(licenseType);
        break;
      }
    }
  }
  return required;
}

module.exports = { scrapeAllCourses };

if (require.main === module) {
  scrapeAllCourses().then(() => process.exit(0));
}
