// scrapers/riyadahScraper.js
// ============================================================
// سحب برامج الدعم من:
//   - معهد ريادة الأعمال (riyadah.com.sa)
//   - منصة جنى (jana.gov.sa)
//   - مؤسسة عبداللطيف جميل (jalc.com.sa)
// ============================================================

const { createBrowser, createPage, safeGoto, randomDelay } = require('../utils/browser');
const { upsertProgram, logScrape } = require('../storage/database');
const logger = require('../utils/logger');

const SOURCES = [
  {
    key: 'riyadah',
    name: 'معهد ريادة الأعمال',
    url: 'https://www.riyadah.com.sa/programs',
    altUrls: [
      'https://www.riyadah.com.sa/ar/programs',
      'https://riyadah.com.sa/services',
    ],
    selectors: {
      cards: '.program-card, .service-card, .initiative-card, .card',
      title: 'h2, h3, .program-title, .card-title',
      desc: '.program-description, .card-text, p',
      type: '.program-type, .badge, .category',
      link: 'a',
    }
  },
  {
    key: 'jana',
    name: 'منصة جنى',
    url: 'https://www.jana.gov.sa/services',
    altUrls: [
      'https://www.jana.gov.sa/ar/services',
      'https://jana.gov.sa/programs',
    ],
    selectors: {
      cards: '.service-card, .program-item, .support-card, .card',
      title: 'h2, h3, h4, .service-title',
      desc: '.service-description, p',
      type: '.service-type, .badge',
      link: 'a',
    }
  },
  {
    key: 'jameel',
    name: 'مؤسسة عبداللطيف جميل',
    url: 'https://www.jalc.com.sa/programs',
    altUrls: [
      'https://jalc.com.sa/ar/programs',
      'https://www.jalc.com.sa/initiatives',
    ],
    selectors: {
      cards: '.program-card, .initiative-card, .card, article',
      title: 'h2, h3, .program-name, .card-title',
      desc: '.program-details, .description, p',
      type: '.program-category, .badge',
      link: 'a',
    }
  }
];

async function scrapeAllPrograms() {
  const startTime = Date.now();
  const allStats = { new: 0, updated: 0, errors: 0 };
  let browser;

  logger.info('🚀 بدء سحب برامج الدعم...');

  try {
    browser = await createBrowser();
    const page = await createPage(browser);

    for (const source of SOURCES) {
      logger.info(`  🏢 سحب: ${source.name}`);
      const stats = await scrapeSource(page, source);
      allStats.new += stats.new;
      allStats.updated += stats.updated;
      allStats.errors += stats.errors;
      await randomDelay(4000, 8000);  // احترام بين المواقع
    }

    const duration = Date.now() - startTime;
    logScrape('support_programs', 'success', { ...allStats, duration });
    logger.info(`✅ اكتمل سحب برامج الدعم: جديد=${allStats.new}, محدَّث=${allStats.updated}, خطأ=${allStats.errors}`);

  } catch (err) {
    const duration = Date.now() - startTime;
    logScrape('support_programs', 'failed', { ...allStats, duration, error: err.message });
    logger.error(`💥 فشل سحب برامج الدعم: ${err.message}`);
  } finally {
    if (browser) await browser.close();
  }

  return allStats;
}

async function scrapeSource(page, source) {
  const stats = { new: 0, updated: 0, errors: 0 };

  // محاولة كل الروابط البديلة
  const urlsToTry = [source.url, ...source.altUrls];
  let loaded = false;

  for (const url of urlsToTry) {
    const ok = await safeGoto(page, url);
    if (ok) {
      // تحقق أن الصفحة فيها محتوى حقيقي
      const hasContent = await page.evaluate((sel) => {
        return document.querySelectorAll(sel).length > 0;
      }, source.selectors.cards);

      if (hasContent) {
        loaded = true;
        logger.info(`    ✓ تم تحميل: ${url}`);
        break;
      }
    }
    await randomDelay(2000, 4000);
  }

  if (!loaded) {
    // إنشاء بيانات أساسية من المعلومات المتاحة (fallback)
    logger.warn(`    ⚠️  لم يُحمَّل ${source.name} - حفظ بيانات أساسية`);
    await saveFallbackData(source, stats);
    return stats;
  }

  // استخراج البيانات
  const programs = await page.evaluate((src) => {
    const items = [];
    const cards = document.querySelectorAll(src.selectors.cards);

    cards.forEach((card, idx) => {
      if (idx > 50) return;

      const titleEl = card.querySelector(src.selectors.title);
      const title_ar = titleEl?.textContent?.trim();
      if (!title_ar || title_ar.length < 5) return;

      const descEl = card.querySelector(src.selectors.desc);
      const typeEl = card.querySelector(src.selectors.type);
      const linkEl = card.querySelector(src.selectors.link);

      // البحث عن مبالغ التمويل
      const allText = card.textContent;
      const amountMatch = allText.match(/(\d[\d,،]*)\s*(ريال|SAR)/);
      const amount = amountMatch ? parseInt(amountMatch[1].replace(/[,،]/g, '')) : null;

      items.push({
        title_ar,
        description: descEl?.textContent?.trim()?.substring(0, 800) || null,
        program_type: typeEl?.textContent?.trim() || null,
        link: linkEl?.getAttribute('href') || null,
        amount,
        _allText: allText.substring(0, 200),
      });
    });

    return items;
  }, source);

  logger.info(`    📦 ${programs.length} برنامج في ${source.name}`);

  for (const prog of programs) {
    try {
      const fullUrl = prog.link
        ? (prog.link.startsWith('http') ? prog.link : source.url.replace(/\/[^/]*$/, '') + prog.link)
        : source.url;

      // تحديد نوع البرنامج
      const programType = detectProgramType(prog.title_ar, prog.description, prog._allText);
      const targetGroup = detectTargetGroup(prog.title_ar, prog.description, prog._allText);

      const record = {
        external_id: `${source.key}_${slugify(prog.title_ar)}_${Date.now()}`,
        name_ar: prog.title_ar,
        name_en: null,
        provider: source.name,
        description: prog.description,
        program_type: prog.program_type || programType,
        target_group: targetGroup,
        benefits: JSON.stringify(extractBenefits(prog._allText)),
        requirements: null,
        amount_min: prog.amount || null,
        amount_max: null,
        deadline: null,
        apply_url: fullUrl,
        contact_info: null,
        regions: JSON.stringify(['المنطقة الوطنية']),
      };

      const result = upsertProgram(record);
      if (result.isNew) stats.new++;
      else stats.updated++;
    } catch (err) {
      logger.error(`❌ خطأ في حفظ برنامج ${prog.title_ar}: ${err.message}`);
      stats.errors++;
    }
  }

  return stats;
}

// حفظ بيانات أساسية معروفة مسبقاً إذا فشل الـ Scraping
async function saveFallbackData(source, stats) {
  const KNOWN_PROGRAMS = {
    riyadah: [
      { name: 'برنامج ريادة الأعمال للشباب', type: 'تدريب وتأهيل', url: 'https://www.riyadah.com.sa' },
      { name: 'تمويل المشاريع الصغيرة', type: 'تمويل', url: 'https://www.riyadah.com.sa/funding' },
      { name: 'برنامج الإرشاد والتوجيه', type: 'إرشاد', url: 'https://www.riyadah.com.sa/mentoring' },
    ],
    jana: [
      { name: 'دعم الأسرة المنتجة', type: 'دعم اجتماعي واقتصادي', url: 'https://www.jana.gov.sa' },
      { name: 'برنامج تأهيل المرأة للعمل', type: 'تأهيل وتدريب', url: 'https://www.jana.gov.sa/women' },
      { name: 'دعم المشاريع المنزلية', type: 'تمويل ودعم', url: 'https://www.jana.gov.sa/home-projects' },
    ],
    jameel: [
      { name: 'برنامج التوظيف والتدريب', type: 'تدريب وتوظيف', url: 'https://www.jalc.com.sa' },
      { name: 'مبادرة ريادة الأعمال', type: 'ريادة أعمال', url: 'https://www.jalc.com.sa/entrepreneurship' },
    ],
  };

  const programs = KNOWN_PROGRAMS[source.key] || [];
  for (const prog of programs) {
    try {
      upsertProgram({
        external_id: `${source.key}_fallback_${slugify(prog.name)}`,
        name_ar: prog.name,
        name_en: null,
        provider: source.name,
        description: `برنامج دعم من ${source.name}`,
        program_type: prog.type,
        target_group: 'الرياديون وأصحاب المشاريع',
        benefits: JSON.stringify([]),
        requirements: null,
        amount_min: null,
        amount_max: null,
        deadline: null,
        apply_url: prog.url,
        contact_info: null,
        regions: JSON.stringify(['المنطقة الوطنية']),
      });
      stats.new++;
    } catch { stats.errors++; }
  }
}

// -------------------------------------------------------
// دوال مساعدة لتحليل النصوص
// -------------------------------------------------------
function detectProgramType(title, desc, text) {
  const combined = `${title} ${desc} ${text}`;
  if (combined.includes('تمويل') || combined.includes('قرض')) return 'تمويل';
  if (combined.includes('تدريب') || combined.includes('دورة')) return 'تدريب';
  if (combined.includes('إرشاد') || combined.includes('توجيه')) return 'إرشاد وتوجيه';
  if (combined.includes('توظيف') || combined.includes('عمل')) return 'توظيف';
  return 'دعم عام';
}

function detectTargetGroup(title, desc, text) {
  const combined = `${title} ${desc} ${text}`;
  if (combined.includes('شباب')) return 'الشباب';
  if (combined.includes('مرأة') || combined.includes('نساء')) return 'المرأة';
  if (combined.includes('أسرة') || combined.includes('عائلة')) return 'الأسر';
  if (combined.includes('صغير') || combined.includes('متوسط')) return 'المنشآت الصغيرة والمتوسطة';
  return 'الرياديون عموماً';
}

function extractBenefits(text) {
  const benefits = [];
  const patterns = ['تمويل', 'تدريب', 'إرشاد', 'شبكة علاقات', 'شهادة', 'منحة'];
  patterns.forEach(p => { if (text.includes(p)) benefits.push(p); });
  return benefits;
}

function slugify(text) {
  return text.replace(/\s+/g, '_').replace(/[^\w\u0600-\u06FF]/g, '').substring(0, 30);
}

module.exports = { scrapeAllPrograms };

if (require.main === module) {
  scrapeAllPrograms().then(() => process.exit(0));
}
