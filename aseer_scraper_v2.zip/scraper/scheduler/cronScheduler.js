// scheduler/cronScheduler.js
// ============================================================
// المجدول التلقائي - يشغّل السحب على فترات منتظمة
// ============================================================

const cron = require('node-cron');
const { scrapeAllFranchises } = require('../scrapers/franchiseScraper');
const { scrapeAllCourses }    = require('../scrapers/doroobScraper');
const { scrapeAllPrograms }   = require('../scrapers/riyadahScraper');
const logger = require('../utils/logger');

// حالة تشغيل لمنع التشغيل المتزامن
const runningJobs = new Set();

async function runJob(name, fn) {
  if (runningJobs.has(name)) {
    logger.warn(`⏭️  تخطي ${name} - لا يزال يعمل`);
    return;
  }
  runningJobs.add(name);
  logger.info(`⏰ [CRON] بدء: ${name}`);
  try {
    await fn();
    logger.info(`✅ [CRON] اكتمل: ${name}`);
  } catch (err) {
    logger.error(`❌ [CRON] فشل: ${name} - ${err.message}`);
  } finally {
    runningJobs.delete(name);
  }
}

function startScheduler() {
  logger.info('🕐 تشغيل المجدول التلقائي...');

  // ===================================================
  // 1️⃣  الامتياز التجاري - كل يوم الساعة 2 صباحاً
  //     البيانات لا تتغير كثيراً، يكفي مرة يومياً
  // ===================================================
  cron.schedule('0 2 * * *', () => {
    runJob('franchise_scraper', scrapeAllFranchises);
  }, { timezone: 'Asia/Riyadh' });

  // ===================================================
  // 2️⃣  دورات دروب - كل يومين الساعة 3 صباحاً
  //     الدورات تتحدث بشكل دوري
  // ===================================================
  cron.schedule('0 3 */2 * *', () => {
    runJob('doroob_scraper', scrapeAllCourses);
  }, { timezone: 'Asia/Riyadh' });

  // ===================================================
  // 3️⃣  برامج الدعم - مرة في الأسبوع (الأحد 4 صباحاً)
  //     برامج الدعم نادراً ما تتغير
  // ===================================================
  cron.schedule('0 4 * * 0', () => {
    runJob('support_programs_scraper', scrapeAllPrograms);
  }, { timezone: 'Asia/Riyadh' });

  // ===================================================
  // 4️⃣  فحص صحة البيانات - كل يوم الساعة 6 صباحاً
  // ===================================================
  cron.schedule('0 6 * * *', () => {
    runJob('health_check', healthCheck);
  }, { timezone: 'Asia/Riyadh' });

  logger.info('✅ المجدول يعمل. الجدول:');
  logger.info('   🏪 الامتياز التجاري: يومياً 02:00 KSA');
  logger.info('   📚 دروب:             كل يومين 03:00 KSA');
  logger.info('   🤝 برامج الدعم:      أسبوعياً (أحد) 04:00 KSA');
  logger.info('   🏥 فحص الصحة:        يومياً 06:00 KSA');
}

async function healthCheck() {
  const { getStats } = require('../storage/database');
  const stats = getStats();
  
  logger.info('📊 إحصائيات قاعدة البيانات:');
  logger.info(`   🏪 الامتيازات: ${stats.franchises.count} (آخر تحديث: ${stats.franchises.last})`);
  logger.info(`   📚 الدورات: ${stats.courses.count} (آخر تحديث: ${stats.courses.last})`);
  logger.info(`   🤝 البرامج: ${stats.programs.count} (آخر تحديث: ${stats.programs.last})`);

  // تحذير إن قدمت البيانات
  const now = Date.now();
  const maxAge = 3 * 24 * 60 * 60 * 1000; // 3 أيام
  
  if (stats.franchises.last) {
    const age = now - new Date(stats.franchises.last).getTime();
    if (age > maxAge) {
      logger.warn('⚠️  بيانات الامتياز قديمة (أكثر من 3 أيام)! سيُعاد السحب...');
      runJob('franchise_scraper_retry', scrapeAllFranchises);
    }
  } else {
    // لا توجد بيانات أصلاً - ابدأ السحب الأولي
    logger.warn('⚠️  لا توجد بيانات امتياز - بدء السحب الأولي...');
    runJob('franchise_initial', scrapeAllFranchises);
  }
}

// ===================================================
// تشغيل يدوي فوري لجميع المصادر
// ===================================================
async function runAllNow() {
  logger.info('🔥 تشغيل فوري لجميع السحابات...');
  await runJob('franchise_scraper', scrapeAllFranchises);
  await runJob('doroob_scraper', scrapeAllCourses);
  await runJob('support_scraper', scrapeAllPrograms);
  logger.info('🏁 اكتمل التشغيل الفوري!');
}

module.exports = { startScheduler, runAllNow, healthCheck };
