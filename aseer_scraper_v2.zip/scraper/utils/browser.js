// utils/browser.js
// إدارة المتصفح مع تقنيات التخفي لتجنب الحجب

const puppeteer = require('puppeteer');
const logger = require('./logger');

// قائمة User Agents حقيقية للتنويع
const USER_AGENTS = [
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0',
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15',
  'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
];

function randomUA() {
  return USER_AGENTS[Math.floor(Math.random() * USER_AGENTS.length)];
}

function randomDelay(min = 1000, max = 3500) {
  return new Promise(r => setTimeout(r, Math.floor(Math.random() * (max - min) + min)));
}

async function createBrowser() {
  const browser = await puppeteer.launch({
    headless: 'new',
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-dev-shm-usage',
      '--disable-accelerated-2d-canvas',
      '--disable-gpu',
      '--window-size=1366,768',
      '--disable-blink-features=AutomationControlled',  // إخفاء أن المتصفح آلي
      '--lang=ar-SA,ar,en-US,en',
    ],
    defaultViewport: { width: 1366, height: 768 }
  });
  return browser;
}

async function createPage(browser) {
  const page = await browser.newPage();
  const ua = randomUA();
  
  await page.setUserAgent(ua);
  await page.setExtraHTTPHeaders({
    'Accept-Language': 'ar-SA,ar;q=0.9,en-US;q=0.8,en;q=0.7',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
    'Accept-Encoding': 'gzip, deflate, br',
    'Cache-Control': 'no-cache',
    'Pragma': 'no-cache',
  });

  // إخفاء علامات Puppeteer
  await page.evaluateOnNewDocument(() => {
    Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
    Object.defineProperty(navigator, 'plugins', { get: () => [1, 2, 3] });
    Object.defineProperty(navigator, 'languages', { get: () => ['ar-SA', 'ar', 'en-US'] });
    window.chrome = { runtime: {} };
  });

  // حجب الصور والخطوط لتسريع التحميل
  await page.setRequestInterception(true);
  page.on('request', (req) => {
    const type = req.resourceType();
    if (['font', 'media'].includes(type)) {
      req.abort();
    } else {
      req.continue();
    }
  });

  return page;
}

async function safeGoto(page, url, retries = 3) {
  for (let i = 0; i < retries; i++) {
    try {
      await page.goto(url, {
        waitUntil: 'domcontentloaded',
        timeout: 30000
      });
      await randomDelay(800, 2000);  // تأخير طبيعي بعد التحميل
      return true;
    } catch (err) {
      logger.warn(`⚠️  محاولة ${i + 1}/${retries} فشلت لـ: ${url} - ${err.message}`);
      if (i < retries - 1) await randomDelay(3000, 6000);
    }
  }
  return false;
}

module.exports = { createBrowser, createPage, safeGoto, randomDelay };
